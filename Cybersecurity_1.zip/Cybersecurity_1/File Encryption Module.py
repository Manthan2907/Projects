import tkinter as tk
from tkinter import filedialog, messagebox
from cryptography.fernet import Fernet
import base64
import pyperclip

# Validate the encryption key
def validate_key(key):
    try:
        # Try to decode and validate the key
        Fernet(key.encode())
        return True
    except Exception:
        return False

# Encrypt a file with a given key
def encrypt_file(file_path, key):
    # Ensure the key is properly formatted
    if not validate_key(key):
        raise ValueError("Invalid encryption key")

    with open(file_path, 'rb') as file:
        data = file.read()
    fernet = Fernet(key.encode())
    encrypted_data = fernet.encrypt(data)
    with open(file_path + '.enc', 'wb') as enc_file:
        enc_file.write(encrypted_data)

# Decrypt a file with a given key
def decrypt_file(file_path, key):
    # Ensure the key is properly formatted
    if not validate_key(key):
        raise ValueError("Invalid encryption key")

    with open(file_path, 'rb') as enc_file:
        encrypted_data = enc_file.read()
    fernet = Fernet(key.encode())
    decrypted_data = fernet.decrypt(encrypted_data)
    with open(file_path.replace('.enc', ''), 'wb') as dec_file:
        dec_file.write(decrypted_data)

# Generate a valid Fernet key
def generate_sample_key():
    return base64.urlsafe_b64encode(Fernet.generate_key()).decode()

# Entry point for the toolkit
def open_encryption_window(root):
    def select_file():
        file_path = filedialog.askopenfilename()
        if file_path:
            file_entry.delete(0, tk.END)
            file_entry.insert(0, file_path)

    def perform_encryption():
        file_path = file_entry.get()
        key = key_entry.get()
        
        try:
            if not key:
                messagebox.showerror("Error", "Please enter an encryption key")
                return
            
            encrypt_file(file_path, key)
            messagebox.showinfo("Success", "File encrypted successfully!")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def perform_decryption():
        file_path = file_entry.get()
        key = key_entry.get()
        
        try:
            if not key:
                messagebox.showerror("Error", "Please enter the decryption key")
                return
            
            decrypt_file(file_path, key)
            messagebox.showinfo("Success", "File decrypted successfully!")
        except Exception as e:
            messagebox.showerror("Error", str(e))

    def generate_key():
        # Generate a sample key and populate the key entry
        sample_key = generate_sample_key()
        key_entry.delete(0, tk.END)
        key_entry.insert(0, sample_key)

    encryption_window = tk.Toplevel(root)
    encryption_window.title("File Encryption Toolkit")
    encryption_window.geometry("400x350")

    tk.Label(encryption_window, text="File Path:").pack(pady=5)
    file_entry = tk.Entry(encryption_window, width=40)
    file_entry.pack()
    tk.Button(encryption_window, text="Select File", command=select_file).pack(pady=5)

    tk.Label(encryption_window, text="Encryption/Decryption Key:").pack(pady=5)
    key_entry = tk.Entry(encryption_window, width=40)
    key_entry.pack()
    tk.Button(encryption_window, text="Generate Sample Key", command=generate_key).pack(pady=5)

    tk.Button(encryption_window, text="Encrypt", command=perform_encryption).pack(pady=10)
    tk.Button(encryption_window, text="Decrypt", command=perform_decryption).pack(pady=10)