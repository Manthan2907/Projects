import random
import string
from tkinter import Toplevel, Entry, Button, Label, messagebox

def generate_password(length):
    characters = string.ascii_letters + string.digits + string.punctuation
    return ''.join(random.choice(characters) for _ in range(length))

def open_password_generator_window(root):
    def create_password():
        try:
            length = int(length_entry.get())
            if length < 8:
                raise ValueError("Password must be at least 8 characters long.")
            password = generate_password(length)
            password_entry.delete(0, 'end')
            password_entry.insert(0, password)
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    password_window = Toplevel(root)
    password_window.title("Password Generator")
    password_window.geometry("400x200")

    Label(password_window, text="Enter password length:").pack(pady=5)
    length_entry = Entry(password_window)
    length_entry.pack()

    Button(password_window, text="Generate Password", command=create_password).pack(pady=10)

    Label(password_window, text="Generated Password:").pack(pady=5)
    password_entry = Entry(password_window, width=40)
    password_entry.pack()

