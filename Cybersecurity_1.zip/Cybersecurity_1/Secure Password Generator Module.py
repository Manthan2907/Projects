import tkinter as tk
from tkinter import messagebox
import random
import string

def generate_password(length=12, use_uppercase=True, use_lowercase=True, 
                      use_numbers=True, use_special_chars=True):
    # Define character sets
    uppercase_chars = string.ascii_uppercase
    lowercase_chars = string.ascii_lowercase
    number_chars = string.digits
    special_chars = string.punctuation

    # Validate length
    if length < 8:
        raise ValueError("Password length must be at least 8 characters")

    # Collect character sets based on user preferences
    char_sets = []
    if use_uppercase:
        char_sets.append(uppercase_chars)
    if use_lowercase:
        char_sets.append(lowercase_chars)
    if use_numbers:
        char_sets.append(number_chars)
    if use_special_chars:
        char_sets.append(special_chars)

    # Ensure at least one character from each selected set
    password = []
    for char_set in char_sets:
        password.append(random.choice(char_set))

    # Fill the rest of the password
    remaining_length = length - len(password)
    all_chars = ''.join(char_sets)
    
    for _ in range(remaining_length):
        password.append(random.choice(all_chars))

    # Shuffle the password
    random.shuffle(password)
    
    return ''.join(password)

def open_password_generator_window(parent):
    generator_window = tk.Toplevel(parent)
    generator_window.title("Secure Password Generator")
    generator_window.geometry("500x450")
    generator_window.configure(bg='#f0f0f0')

    # Password Length
    tk.Label(generator_window, text="Password Length:", bg='#f0f0f0').pack(pady=5)
    length_var = tk.IntVar(value=12)
    length_spinbox = tk.Spinbox(
        generator_window, 
        from_=8, 
        to=32, 
        textvariable=length_var, 
        width=10
    )
    length_spinbox.pack(pady=5)

    # Character Set Options
    char_options_frame = tk.Frame(generator_window, bg='#f0f0f0')
    char_options_frame.pack(pady=10)

    uppercase_var = tk.BooleanVar(value=True)
    lowercase_var = tk.BooleanVar(value=True)
    numbers_var = tk.BooleanVar(value=True)
    special_chars_var = tk.BooleanVar(value=True)

    tk.Checkbutton(
        char_options_frame, 
        text="Uppercase Letters", 
        variable=uppercase_var, 
        bg='#f0f0f0'
    ).grid(row=0, column=0, padx=5)
    
    tk.Checkbutton(
        char_options_frame, 
        text="Lowercase Letters", 
        variable=lowercase_var, 
        bg='#f0f0f0'
    ).grid(row=0, column=1, padx=5)
    
    tk.Checkbutton(
        char_options_frame, 
        text="Numbers", 
        variable=numbers_var, 
        bg='#f0f0f0'
    ).grid(row=1, column=0, padx=5)
    
    tk.Checkbutton(
        char_options_frame, 
        text="Special Characters", 
        variable=special_chars_var, 
        bg='#f0f0f0'
    ).grid(row=1, column=1, padx=5)

    # Generated Password Display
    password_var = tk.StringVar()
    password_entry = tk.Entry(
        generator_window, 
        textvariable=password_var, 
        width=40, 
        show="*"
    )
    password_entry.pack(pady=10)

    # Show/Hide Password
    show_var = tk.BooleanVar()
    def toggle_password_visibility():
        password_entry.config(show="" if show_var.get() else "*")

    show_checkbox = tk.Checkbutton(
        generator_window, 
        text="Show Password", 
        variable=show_var, 
        command=toggle_password_visibility, 
        bg='#f0f0f0'
    )
    show_checkbox.pack(pady=5)

    # Generate Button
    def generate_new_password():
        try:
            new_password = generate_password(
                length=length_var.get(),
                use_uppercase=uppercase_var.get(),
                use_lowercase=lowercase_var.get(),
                use_numbers=numbers_var.get(),
                use_special_chars=special_chars_var.get()
            )
            password_var.set(new_password)
        except ValueError as e:
            messagebox.showerror("Error", str(e))

    generate_btn = tk.Button(
        generator_window, 
        text="Generate Password", 
        command=generate_new_password,
        bg='#4CAF50', 
        fg='white'
    )
    generate_btn.pack(pady=10)

    # Copy to Clipboard
    def copy_to_clipboard():
        generator_window.clipboard_clear()
        generator_window.clipboard_append(password_var.get())
        messagebox.showinfo("Copied", "Password copied to clipboard!")

    copy_btn = tk.Button(
        generator_window, 
        text="Copy Password", 
        command=copy_to_clipboard,
        bg='#2196F3', 
        fg='white'
    )
    copy_btn.pack(pady=10)