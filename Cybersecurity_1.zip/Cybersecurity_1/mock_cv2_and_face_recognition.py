import random

class MockVideoCapture:
    def __init__(self, index=0):
        print("MockVideoCapture initialized. Simulating webcam...")
        self.index = index
        self.is_open = True

    def read(self):
        # Simulate reading a frame from the webcam
        print("Simulated video frame captured.")
        # Return success (True) and a dummy frame (e.g., a 2D array)
        return True, [[random.randint(0, 255) for _ in range(100)] for _ in range(100)]

    def release(self):
        print("MockVideoCapture released.")
        self.is_open = False

def imshow(window_name, frame):
    # Simulate displaying a frame
    print(f"Simulating display of a frame in window '{window_name}'.")

def waitKey(delay):
    # Simulate a key press. Return `ord('q')` to simulate 'q' being pressed after some time.
    return ord('q') if random.random() > 0.8 else -1

def destroyAllWindows():
    # Simulate closing all OpenCV windows
    print("Simulated closing of all OpenCV windows.")

def compare_faces(known_face_encodings, face_encoding_to_check):
    # Simulate face comparison
    print("Simulating face comparison...")
    return [random.choice([True, False])]

def face_locations(image):
    # Simulate detecting face locations
    print("Simulating face location detection...")
    return [(0, 0, 50, 50)]  # Example bounding box coordinates

def face_encodings(image, known_face_locations=None):
    # Simulate generating face encodings
    print("Simulating face encoding generation...")
    return [[random.random() for _ in range(128)]]  # Example encoding of size 128
