import tkinter as tk
from tkinter import filedialog, messagebox
import mock_cv2_and_face_recognition as cv2
import mock_cv2_and_face_recognition as face_recognition
import os
import threading
from cryptography.fernet import Fernet

class FaceRecognitionLocker:
    def __init__(self, parent_root):
        self.parent_root = parent_root
        self.reference_image_path = None
        self.file_to_lock = None
        self.key_path = "filekey.key"

    def generate_encryption_key(self):
        """Generate a new encryption key if not exists"""
        if not os.path.exists(self.key_path):
            key = Fernet.generate_key()
            with open(self.key_path, "wb") as keyfile:
                keyfile.write(key)
        return self.key_path

    def encrypt_file(self, file_path):
        """Encrypt a file"""
        try:
            with open(self.key_path, "rb") as keyfile:
                key = keyfile.read()
            cipher = Fernet(key)
            
            with open(file_path, "rb") as file:
                encrypted_data = cipher.encrypt(file.read())
            
            locked_file_path = file_path + ".locked"
            with open(locked_file_path, "wb") as enc_file:
                enc_file.write(encrypted_data)
            
            os.remove(file_path)  # Remove original file
            return locked_file_path
        except Exception as e:
            messagebox.showerror("Encryption Error", str(e))
            return None

    def decrypt_file(self, locked_file_path):
        """Decrypt a locked file"""
        try:
            with open(self.key_path, "rb") as keyfile:
                key = keyfile.read()
            cipher = Fernet(key)
            
            with open(locked_file_path, "rb") as enc_file:
                decrypted_data = cipher.decrypt(enc_file.read())
            
            decrypted_file_path = locked_file_path.replace(".locked", "")
            with open(decrypted_file_path, "wb") as dec_file:
                dec_file.write(decrypted_data)
            
            os.remove(locked_file_path)  # Remove locked file
            return decrypted_file_path
        except Exception as e:
            messagebox.showerror("Decryption Error", str(e))
            return None

    def open_face_recognition_locker(self):
        """Open the face recognition locker window"""
        # Generate encryption key first
        self.generate_encryption_key()

        # Create locker window
        locker_window = tk.Toplevel(self.parent_root)
        locker_window.title("Face Recognition File Locker")
        locker_window.geometry("500x600")
        locker_window.configure(bg='#f0f0f0')

        # Frame for content
        frame = tk.Frame(locker_window, bg='#f0f0f0')
        frame.pack(expand=True, fill='both', padx=20, pady=20)

        # Title
        title_label = tk.Label(
            frame, 
            text="Face Recognition File Locker", 
            font=('Arial', 16, 'bold'), 
            bg='#f0f0f0',
            fg='#333333'
        )
        title_label.pack(pady=10)

        # Reference Image Selection
        def select_reference_image():
            self.reference_image_path = filedialog.askopenfilename(
                title="Select Reference Face Image",
                filetypes=[("Image files", "*.jpg *.jpeg *.png")]
            )
            if self.reference_image_path:
                ref_label.config(text=f"Reference Image: {os.path.basename(self.reference_image_path)}")

        ref_btn = tk.Button(
            frame, 
            text="Select Reference Face", 
            command=select_reference_image,
            bg='#4CAF50', 
            fg='white', 
            font=('Arial', 12)
        )
        ref_btn.pack(pady=10)

        ref_label = tk.Label(
            frame, 
            text="No reference image selected", 
            font=('Arial', 10), 
            bg='#f0f0f0'
        )
        ref_label.pack(pady=5)

        # File Selection
        def select_file_to_lock():
            self.file_to_lock = filedialog.askopenfilename(
                title="Select File to Lock"
            )
            if self.file_to_lock:
                file_label.config(text=f"Selected File: {os.path.basename(self.file_to_lock)}")

        file_btn = tk.Button(
            frame, 
            text="Select File to Lock", 
            command=select_file_to_lock,
            bg='#2196F3', 
            fg='white', 
            font=('Arial', 12)
        )
        file_btn.pack(pady=10)

        file_label = tk.Label(
            frame, 
            text="No file selected", 
            font=('Arial', 10), 
            bg='#f0f0f0'
        )
        file_label.pack(pady=5)

        # Status Label
        status_label = tk.Label(
            frame, 
            text="", 
            font=('Arial', 10), 
            bg='#f0f0f0'
        )
        status_label.pack(pady=5)

        def start_face_recognition():
            # Validation
            if not self.reference_image_path:
                messagebox.showwarning("Warning", "Please select a reference face image")
                return
            if not self.file_to_lock:
                messagebox.showwarning("Warning", "Please select a file to lock")
                return

            # Load reference image and encode
            try:
                reference_image = face_recognition.load_image_file(self.reference_image_path)
                reference_encoding = face_recognition.face_encodings(reference_image)[0]
            except Exception as e:
                messagebox.showerror("Error", f"Could not process reference image: {str(e)}")
                return

            # Start webcam in a separate thread
            def face_recognition_thread():
                video_capture = cv2.VideoCapture(0)
                
                while True:
                    ret, frame = video_capture.read()
                    if not ret:
                        break

                    # Convert frame to RGB
                    rgb_frame = frame[:, :, ::-1]
                    
                    # Detect faces
                    face_locations = face_recognition.face_locations(rgb_frame)
                    face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)

                    for face_encoding in face_encodings:
                        # Compare faces
                        matches = face_recognition.compare_faces([reference_encoding], face_encoding)
                        
                        if True in matches:
                            # Face recognized
                            video_capture.release()
                            cv2.destroyAllWindows()
                            
                            # Encrypt file
                            locked_file = self.encrypt_file(self.file_to_lock)
                            
                            # Show success message
                            locker_window.after(0, lambda: messagebox.showinfo(
                                "Success", 
                                f"File locked successfully!\nLocked file: {locked_file}"
                            ))
                            return

                    # Show video
                    cv2.imshow("Face Recognition - Scanning", frame)
                    
                    # Exit on 'q'
                    if cv2.waitKey(1) & 0xFF == ord('q'):
                        break

                video_capture.release()
                cv2.destroyAllWindows()

            # Start face recognition in a thread
            threading.Thread(target=face_recognition_thread, daemon=True).start()

            # Update status
            status_label.config(text="Scanning... Look at the camera", fg='green')

        # Lock File Button
        lock_btn = tk.Button(
            frame, 
            text="Start Face Recognition Lock", 
            command=start_face_recognition,
            bg='#FF9800', 
            fg='white', 
            font=('Arial', 12)
        )
        lock_btn.pack(pady=10)

def open_face_recognition_locker(parent_root):
    """Wrapper function to create FaceRecognitionLocker instance"""
    face_locker = FaceRecognitionLocker(parent_root)
    face_locker.open_face_recognition_locker()