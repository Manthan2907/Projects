import tkinter as tk
from tkinter import messagebox
import random
import time
import threading
import pyperclip

def generate_otp(length=6):
    """Generate a random OTP of specified length."""
    return ''.join(random.choices('0123456789', k=length))

def open_mfa_window(parent_root):
    # Create a new top-level window
    mfa_window = tk.Toplevel(parent_root)
    mfa_window.title("Multi-Factor Authentication")
    mfa_window.geometry("400x300")
    mfa_window.configure(bg='#f0f0f0')

    # Generate OTP
    correct_otp = generate_otp()

    # OTP Entry Frame
    frame = tk.Frame(mfa_window, bg='#f0f0f0')
    frame.pack(expand=True, fill='both', padx=20, pady=20)

    # Title
    title_label = tk.Label(
        frame, 
        text="Multi-Factor Authentication", 
        font=('Arial', 16, 'bold'), 
        bg='#f0f0f0',
        fg='#333333'
    )
    title_label.pack(pady=10)

    # OTP Instructions
    instruction_label = tk.Label(
        frame, 
        text="An OTP will be sent to your registered device\n", 
        font=('Arial', 12), 
        bg='#f0f0f0',
        fg='#555555',
        justify=tk.CENTER
    )
    instruction_label.pack(pady=10)

    # OTP Entry
    otp_label = tk.Label(
        frame, 
        text="Enter 6-Digit OTP:", 
        font=('Arial', 12), 
        bg='#f0f0f0'
    )
    otp_label.pack(pady=5)

    otp_entry = tk.Entry(
        frame, 
        font=('Arial', 14), 
        justify='center',
        width=10
    )
    otp_entry.pack(pady=5)

    # Status Label
    status_label = tk.Label(
        frame, 
        text="", 
        font=('Arial', 10), 
        bg='#f0f0f0'
    )
    status_label.pack(pady=5)

    def show_otp():
        """Simulate sending OTP after 5 seconds"""
        # Copy OTP to clipboard for "sending"
        pyperclip.copy(correct_otp)
        
        messagebox.showinfo(
            "OTP Generated", 
            f"Your OTP is: {correct_otp}\n(Copied to clipboard)"
        )

    def verify_otp():
        """Verify the entered OTP"""
        entered_otp = otp_entry.get()
        
        if entered_otp == correct_otp:
            status_label.config(text="Authentication Successful!", fg='green')
            messagebox.showinfo("Success", "Multi-Factor Authentication Passed!")
            mfa_window.destroy()
        else:
            status_label.config(text="Incorrect OTP. Try again.", fg='red')
            otp_entry.delete(0, tk.END)

    # Verify Button
    verify_button = tk.Button(
        frame, 
        text="Verify OTP", 
        command=verify_otp,
        bg='#4CAF50', 
        fg='white', 
        font=('Arial', 12)
    )
    verify_button.pack(pady=10)

    # Schedule OTP display after 5 seconds
    mfa_window.after(5000, show_otp)