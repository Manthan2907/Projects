import tkinter as tk
from tkinter import filedialog, messagebox, simpledialog
from cryptography.fernet import Fernet
import pyperclip

def open_file_encryption_window(root):
    encryption_window = tk.Toplevel(root)
    app = FileEncryptionToolkit(encryption_window)

class FileEncryptionToolkit:
    def __init__(self, root):
        self.root = root
        self.root.title("Advanced File Encryption Toolkit")
        self.root.geometry("500x400")

        # File Path Section
        tk.Label(root, text="File Path:").pack(pady=5)
        self.file_entry = tk.Entry(root, width=50)
        self.file_entry.pack()
        tk.Button(root, text="Select File", command=self.select_file).pack(pady=5)

        # Key Generation Option
        tk.Label(root, text="Key Generation Method:").pack(pady=5)
        self.key_var = tk.StringVar(value="generate")
        tk.Radiobutton(root, text="Generate New Key", variable=self.key_var, 
                       value="generate").pack()
        tk.Radiobutton(root, text="Use Custom Key", variable=self.key_var, 
                       value="custom").pack()

        # Key Entry Section
        tk.Label(root, text="Encryption/Decryption Key:").pack(pady=5)
        self.key_entry = tk.Entry(root, width=50, show="*")
        self.key_entry.pack()

        # Copy Key Button
        tk.Button(root, text="Copy Key", command=self.copy_key).pack(pady=5)

        # Encryption and Decryption Buttons
        tk.Button(root, text="Encrypt", command=self.perform_encryption).pack(pady=10)
        tk.Button(root, text="Decrypt", command=self.perform_decryption).pack(pady=10)

    def select_file(self):
        file_path = filedialog.askopenfilename()
        if file_path:
            self.file_entry.delete(0, tk.END)
            self.file_entry.insert(0, file_path)

    def copy_key(self):
        key = self.key_entry.get()
        if key:
            pyperclip.copy(key)
            messagebox.showinfo("Success", "Key copied to clipboard!")
        else:
            messagebox.showwarning("Warning", "No key available to copy.")

    def perform_encryption(self):
        file_path = self.file_entry.get()
        if not file_path:
            messagebox.showerror("Error", "Please select a file to encrypt.")
            return

        try:
            # Key generation or use
            if self.key_var.get() == "generate":
                key = Fernet.generate_key()
                key_str = key.decode()
            else:
                key_str = self.key_entry.get()
                if not key_str:
                    messagebox.showerror("Error", "Please enter a custom key.")
                    return
                key = key_str.encode()

            # Encryption process
            with open(file_path, 'rb') as file:
                data = file.read()
            fernet = Fernet(key)
            encrypted_data = fernet.encrypt(data)
            
            # Save encrypted file
            encrypted_file_path = file_path + '.enc'
            with open(encrypted_file_path, 'wb') as enc_file:
                enc_file.write(encrypted_data)

            # Update key entry and show success message
            self.key_entry.delete(0, tk.END)
            self.key_entry.insert(0, key_str)
            messagebox.showinfo("Success", f"File encrypted!\nSave the key: {key_str}")

        except Exception as e:
            messagebox.showerror("Encryption Error", str(e))

    def perform_decryption(self):
        file_path = self.file_entry.get()
        if not file_path:
            messagebox.showerror("Error", "Please select a file to decrypt.")
            return

        try:
            # Get decryption key
            key_str = self.key_entry.get()
            if not key_str:
                messagebox.showerror("Error", "Please enter the decryption key.")
                return
            key = key_str.encode()

            # Decryption process
            with open(file_path, 'rb') as enc_file:
                encrypted_data = enc_file.read()
            fernet = Fernet(key)
            decrypted_data = fernet.decrypt(encrypted_data)
            
            # Save decrypted file
            decrypted_file_path = file_path.replace('.enc', '_decrypted')
            with open(decrypted_file_path, 'wb') as dec_file:
                dec_file.write(decrypted_data)

            messagebox.showinfo("Success", f"File decrypted to {decrypted_file_path}")

        except Exception as e:
            messagebox.showerror("Decryption Error", 
                                 "Decryption failed. Check if the key is correct.")