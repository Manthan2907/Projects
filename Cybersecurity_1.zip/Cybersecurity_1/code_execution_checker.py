import tkinter as tk
from tkinter import scrolledtext, messagebox, simpledialog
import sys
import io
import traceback

class CodeExecutionChecker:
    def open_execution_checker_window(self, root):
        # Create a new window for code execution
        window = tk.Toplevel(root)
        window.title("Python Code Executor")
        window.geometry("900x700")

        # Create input text area
        input_label = tk.Label(window, text="Enter Python Code:", font=('Arial', 12))
        input_label.pack(pady=(10, 5))

        input_area = scrolledtext.ScrolledText(
            window, 
            wrap=tk.WORD, 
            width=100, 
            height=20, 
            font=('Courier', 10)
        )
        input_area.pack(padx=10, pady=5)

        # Create output text area
        output_label = tk.Label(window, text="Output/Errors:", font=('Arial', 12))
        output_label.pack(pady=(10, 5))

        output_area = scrolledtext.ScrolledText(
            window, 
            wrap=tk.WORD, 
            width=100, 
            height=10, 
            font=('Courier', 10),
            state=tk.DISABLED
        )
        output_area.pack(padx=10, pady=5)

        def run_code():
            # Clear previous output
            output_area.config(state=tk.NORMAL)
            output_area.delete('1.0', tk.END)
            
            # Get the code from input area
            code = input_area.get('1.0', tk.END).strip()
            
            if not code:
                messagebox.showwarning("Warning", "Please enter some code to run.")
                return

            # Redirect stdout and stderr
            old_stdout = sys.stdout
            old_stderr = sys.stderr
            redirected_output = sys.stdout = sys.stderr = io.StringIO()

            try:
                # Execute the code
                exec(code)
                
                # Capture output
                output = redirected_output.getvalue()
                
                # Display output
                if output:
                    output_area.insert(tk.END, "✅ Output:\n" + output)
                else:
                    output_area.insert(tk.END, "✅ Code executed successfully with no output.\n")
            
            except Exception as e:
                # Capture and display error traceback
                error_traceback = traceback.format_exc()
                output_area.insert(tk.END, "❌ Execution Error:\n" + error_traceback)
            
            finally:
                # Restore original stdout and stderr
                sys.stdout = old_stdout
                sys.stderr = old_stderr
                output_area.config(state=tk.DISABLED)

        def save_code():
            # Prompt for filename
            filename = simpledialog.askstring("Save Code", "Enter filename (including .py extension):")
            if filename:
                try:
                    with open(filename, 'w') as file:
                        file.write(input_area.get('1.0', tk.END).strip())
                    messagebox.showinfo("Success", f"Code saved to {filename}")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to save file: {str(e)}")

        def load_code():
            # Prompt for filename
            filename = simpledialog.askstring("Load Code", "Enter filename (including .py extension):")
            if filename:
                try:
                    with open(filename, 'r') as file:
                        code = file.read()
                    input_area.delete('1.0', tk.END)
                    input_area.insert(tk.END, code)
                    messagebox.showinfo("Success", f"Code loaded from {filename}")
                except FileNotFoundError:
                    messagebox.showerror("Error", f"File {filename} not found")
                except Exception as e:
                    messagebox.showerror("Error", f"Failed to load file: {str(e)}")

        # Buttons frame
        button_frame = tk.Frame(window)
        button_frame.pack(pady=10)

        # Run Code Button
        run_button = tk.Button(
            button_frame, 
            text="Run Code", 
            command=run_code,
            font=('Arial', 12),
            bg='#4CAF50',
            fg='white'
        )
        run_button.pack(side=tk.LEFT, padx=5)

        # Save Code Button
        save_button = tk.Button(
            button_frame, 
            text="Save Code", 
            command=save_code,
            font=('Arial', 12),
            bg='#2196F3',
            fg='white'
        )
        save_button.pack(side=tk.LEFT, padx=5)

        # Load Code Button
        load_button = tk.Button(
            button_frame, 
            text="Load Code", 
            command=load_code,
            font=('Arial', 12),
            bg='#FF9800',
            fg='white'
        )
        load_button.pack(side=tk.LEFT, padx=5)

# Allow direct execution of the module
def open_execution_checker_window(root):
    checker = CodeExecutionChecker()
    checker.open_execution_checker_window(root)

if __name__ == "__main__":
    root = tk.Tk()
    open_execution_checker_window(root)
    root.mainloop()