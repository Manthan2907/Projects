import tkinter as tk
from tkinter import filedialog, messagebox
import re

class SuspiciousFileDetector:
    SUSPICIOUS_KEYWORDS = [
        'password', 'confidential', 'secret', 'credentials', 
        'credit card', 'sensitive', 'private', 'classified'
    ]

    @classmethod
    def detect_suspicious_content(cls, file_path):
        try:
            with open(file_path, 'r', encoding='utf-8') as file:
                content = file.read().lower()
                
                # Detect suspicious keywords
                found_keywords = []
                for keyword in cls.SUSPICIOUS_KEYWORDS:
                    matches = re.findall(r'\b' + re.escape(keyword) + r'\b', content)
                    if matches:
                        found_keywords.extend(matches)
                
                # Count line numbers with suspicious content
                suspicious_lines = []
                for i, line in enumerate(content.split('\n'), 1):
                    line_lower = line.lower()
                    line_keywords = [kw for kw in cls.SUSPICIOUS_KEYWORDS if kw in line_lower]
                    if line_keywords:
                        suspicious_lines.append((i, line_keywords))
                
                return found_keywords, suspicious_lines
        except Exception as e:
            messagebox.showerror("File Read Error", str(e))
            return [], []

def open_suspicious_file_detector_window(parent):
    detector_window = tk.Toplevel(parent)
    detector_window.title("Suspicious File Detector")
    detector_window.geometry("600x500")
    detector_window.configure(bg='#f0f0f0')

    # File Selection
    def select_file():
        file_path = filedialog.askopenfilename(
            filetypes=[("Text Files", "*.txt"), ("All Files", "*.*")]
        )
        if file_path:
            # Detect suspicious content
            keywords, suspicious_lines = SuspiciousFileDetector.detect_suspicious_content(file_path)
            
            # Clear previous results
            results_text.delete(1.0, tk.END)
            
            # Display results
            if keywords or suspicious_lines:
                results_text.insert(tk.END, "🚨 Potential Risks Detected:\n\n")
                
                # List unique keywords
                if keywords:
                    results_text.insert(tk.END, "Suspicious Keywords Found:\n")
                    for kw in set(keywords):
                        results_text.insert(tk.END, f"- {kw}\n")
                    results_text.insert(tk.END, "\n")
                
                # List suspicious lines
                if suspicious_lines:
                    results_text.insert(tk.END, "Suspicious Lines:\n")
                    for line_num, line_keywords in suspicious_lines:
                        results_text.insert(tk.END, f"Line {line_num}: Keywords {line_keywords}\n")
            else:
                results_text.insert(tk.END, "✅ No suspicious content detected.")

    # File Selection Button
    select_file_btn = tk.Button(
        detector_window, 
        text="Select File to Scan", 
        command=select_file,
        bg='#4CAF50', 
        fg='white'
    )
    select_file_btn.pack(pady=20)

    # Results Display
    results_text = tk.Text(
        detector_window, 
        height=15, 
        width=70, 
        wrap=tk.WORD,
        bg='white',
        fg='black'
    )
    results_text.pack(pady=10)

    # Custom Keyword Option
    tk.Label(
        detector_window, 
        text="Add Custom Suspicious Keywords (comma-separated):", 
        bg='#f0f0f0'
    ).pack(pady=5)

    custom_keywords_entry = tk.Entry(
        detector_window, 
        width=50
    )
    custom_keywords_entry.pack(pady=5)

    def add_custom_keywords():
        custom_keywords = custom_keywords_entry.get().lower().split(',')
        custom_keywords = [kw.strip() for kw in custom_keywords if kw.strip()]
        
        # Add to existing suspicious keywords
        SuspiciousFileDetector.SUSPICIOUS_KEYWORDS.extend(custom_keywords)
        messagebox.showinfo("Updated", f"Added {len(custom_keywords)} custom keywords")

    add_keywords_btn = tk.Button(
        detector_window, 
        text="Add Keywords", 
        command=add_custom_keywords,
        bg='#2196F3', 
        fg='white'
    )
    add_keywords_btn.pack(pady=10)