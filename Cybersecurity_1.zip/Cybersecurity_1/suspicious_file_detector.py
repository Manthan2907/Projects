import re
from tkinter import Toplevel, filedialog, Label, Button, messagebox

def scan_file(file_path):
    suspicious_keywords = ["password", "secret", "confidential", "key"]
    with open(file_path, 'r') as file:
        content = file.read()
        for keyword in suspicious_keywords:
            if re.search(r'\b' + keyword + r'\b', content, re.IGNORECASE):
                return True
    return False

def open_suspicious_file_detector_window(root):
    def detect_file():
        file_path = filedialog.askopenfilename(filetypes=[("Text Files", "*.txt")])
        if file_path:
            if scan_file(file_path):
                messagebox.showwarning("Suspicious File", "The file contains sensitive keywords!")
            else:
                messagebox.showinfo("Safe File", "No suspicious content detected.")

    detector_window = Toplevel(root)
    detector_window.title("Suspicious File Detector")
    detector_window.geometry("400x200")

    Label(detector_window, text="Detect sensitive keywords in a file").pack(pady=10)
    Button(detector_window, text="Select File", command=detect_file).pack(pady=20)

