import tkinter as tk
from tkinter import messagebox
import re

def check_password_strength(password):
    # Check length
    if len(password) < 8:
        return "Weak", "Password must be at least 8 characters long"
    
    # Check complexity
    has_uppercase = bool(re.search(r'[A-Z]', password))
    has_lowercase = bool(re.search(r'[a-z]', password))
    has_number = bool(re.search(r'\d', password))
    has_special = bool(re.search(r'[!@#$%^&*(),.?":{}|<>]', password))

    # Count criteria met
    strength_count = sum([has_uppercase, has_lowercase, has_number, has_special])

    if strength_count == 4:
        return "Strong", "Your password is strong and meets all complexity requirements!"
    elif strength_count >= 2:
        return "Moderate", "Your password is moderate. Consider adding more complexity."
    else:
        return "Weak", "Your password is weak. Add more character types."

def open_password_strength_window(parent):
    strength_window = tk.Toplevel(parent)
    strength_window.title("Password Strength Checker")
    strength_window.geometry("400x300")
    strength_window.configure(bg='#f0f0f0')

    # Password Input
    tk.Label(strength_window, text="Enter Password:", bg='#f0f0f0').pack(pady=10)
    password_entry = tk.Entry(strength_window, show="*", width=30)
    password_entry.pack(pady=10)

    # Result Label
    result_label = tk.Label(strength_window, text="", bg='#f0f0f0')
    result_label.pack(pady=10)

    def check_strength():
        password = password_entry.get()
        strength, message = check_password_strength(password)
        result_label.config(text=f"Strength: {strength}\n{message}")

    # Check Button
    check_btn = tk.Button(strength_window, text="Check Strength", command=check_strength)
    check_btn.pack(pady=10)

    # Show Password Checkbox
    show_var = tk.BooleanVar()
    show_checkbox = tk.Checkbutton(
        strength_window, 
        text="Show Password", 
        variable=show_var, 
        command=lambda: password_entry.config(show="" if show_var.get() else "*"),
        bg='#f0f0f0'
    )
    show_checkbox.pack(pady=10)