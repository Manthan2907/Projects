import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
from tkinter import filedialog, messagebox

# Function to load data from an Excel file
def load_data(file_path):
    df = pd.read_excel(file_path)
    return df

# Preprocess the data: handle missing values, sort data
def preprocess_data(df):
    df['Date'] = pd.to_datetime(df['Date'], errors='coerce')
    df.dropna(subset=['Amount', 'Date'], inplace=True)
    df.sort_values(by='Date', inplace=True)
    return df

# Anomaly Detection using Isolation Forest
def detect_anomalies(df):
    scaler = StandardScaler()
    df['Amount_Scaled'] = scaler.fit_transform(df[['Amount']])
    
    # Isolation Forest for anomaly detection
    model = IsolationForest(contamination=0.05)  # Contamination is the fraction of anomalies
    df['Anomaly'] = model.fit_predict(df[['Amount_Scaled']])
    
    df['Anomaly'] = df['Anomaly'].apply(lambda x: 'Anomaly' if x == -1 else 'Normal')
    return df

# Plot the anomalies
def plot_anomalies(df):
    plt.figure(figsize=(10, 6))
    plt.plot(df['Date'], df['Amount'], label='Transaction Amount', color='blue', alpha=0.7)
    anomalies = df[df['Anomaly'] == 'Anomaly']
    plt.scatter(anomalies['Date'], anomalies['Amount'], color='red', label='Anomaly', marker='o', s=100, zorder=5)
    
    plt.title('Bank Transaction Anomaly Detection')
    plt.xlabel('Date')
    plt.ylabel('Transaction Amount')
    plt.legend()
    plt.show()

# Export results to an Excel file
def export_results(df, output_file='fraud_detection_results.xlsx'):
    df.to_excel(output_file, index=False)

# Main function to trigger anomaly detection
def run_anomaly_detection(root):
    # Open file dialog to select Excel file
    file_path = filedialog.askopenfilename(title="Select the Transaction Data Excel File", filetypes=(("Excel Files", "*.xlsx"), ("All Files", "*.*")))
    if not file_path:
        return  # If no file selected, return early

    # Load the data
    df = load_data(file_path)
    # Preprocess the data
    df = preprocess_data(df)
    # Detect anomalies
    df = detect_anomalies(df)
    # Plot anomalies
    plot_anomalies(df)
    # Export results
    export_results(df)
    
    # Show success message
    messagebox.showinfo("Fraud Detection", "The anomalies have been detected and results have been saved!")

