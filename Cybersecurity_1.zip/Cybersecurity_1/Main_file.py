import tkinter as tk
from tkinter import messagebox, filedialog
import password_strength_checker
import file_encryption
import password_generator
import suspicious_file_detector
import code_execution_checker
import pyperclip
import multi_factor_auth
import mock_cv2_and_face_recognition as cv2
import mock_cv2_and_face_recognition as face_recognition
import face_recognition_locker
import anomaly  # This is where the anomaly detection code will be imported


class CyberSecurityToolkit:
    def __init__(self, root):
        self.root = root
        self.root.title("Cybersecurity Awareness Toolkit")
        self.root.geometry("800x600")
        self.root.configure(bg='#f0f0f0')

        # Home Page Content
        self.create_home_page()

    def create_home_page(self):
        # Clear any existing widgets
        for widget in self.root.winfo_children():
            widget.destroy()

        # Title
        title_label = tk.Label(
            self.root, 
            text="CyberDefend X", 
            font=('Arial', 35, 'bold'), 
            bg='#f0f0f0',
            fg='#333333'
        )
        title_label.pack(pady=20)

        # Description
        desc_label = tk.Label(
            self.root, 
            text="Empowering Digital Security Through Python", 
            font=('Arial', 14),
            bg='#f0f0f0',
            fg='#555555'
        )
        desc_label.pack(pady=10)

        # Create frame for buttons
        button_frame = tk.Frame(self.root, bg='#f0f0f0')
        button_frame.pack(expand=True)

        # Tool Buttons
        tools = [
            ("Password Strength Checker", self.open_password_strength),
            ("File Encryption", self.open_file_encryption),
            ("Password Generator", self.open_password_generator),
            ("Suspicious File Detector", self.open_suspicious_file_detector),
            ("Code Syntax Checker", self.open_code_syntax_checker),
            ("OTP Generator", self.open_mfa_simulator),
            ("Face Recognition File Locker", self.open_face_recognition_file_locker),
            ("Anomaly Detector", self.open_anomaly),  # This will open the anomaly detection tool
        ]

        for tool_name, command in tools:
            btn = tk.Button(
                button_frame, 
                text=tool_name, 
                command=command,
                width=30,
                bg='#4CAF50', 
                fg='white', 
                font=('Arial', 12)
            )
            btn.pack(pady=10)

    def open_password_strength(self):
        password_strength_checker.open_password_strength_window(self.root)

    def open_file_encryption(self):
        file_encryption.open_file_encryption_window(self.root)

    def open_password_generator(self):
        password_generator.open_password_generator_window(self.root)

    def open_suspicious_file_detector(self):
        suspicious_file_detector.open_suspicious_file_detector_window(self.root)

    def open_code_syntax_checker(self):
        code_execution_checker.open_execution_checker_window(self.root)

    def open_mfa_simulator(self):
        multi_factor_auth.open_mfa_window(self.root)

    def open_face_recognition_file_locker(self):
        face_recognition_locker.open_face_recognition_locker(self.root)

    def open_anomaly(self):
        # This will open the anomaly detection functionality from anomaly.py
        anomaly.run_anomaly_detection(self.root)  # Running the anomaly detection function

def main():
    root = tk.Tk()
    app = CyberSecurityToolkit(root)
    root.mainloop()

if __name__ == "__main__":
    main()
